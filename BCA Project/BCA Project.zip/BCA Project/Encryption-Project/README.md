# Encryption-Project
Encryption System :
Encryption System is yet another learning time project developed in java, the idea about it came when I was studing Network Security in my class. And then and there I thought I should come up with something related to this. So thats how this Encryption System came into reality for me. Till now it support .txt and .java files only and later, I will be adding some more to it.
What it does is, it simply takes an input file of any of the two above mentioned format and then convert it into some non-readable (cipher text)  format, with some password, and this password is only known to sender and receiver.
So in this way the sender will send the cipher text to the receiver using the public network and without taking any risk, as in the mean time if some unauthorized user will try to read or intercept it then he will not going to make out any sense out of those non readable cipher text contain.
So at the receiver's end upon receiving the cipher text message he will use this Encryption System and the same password used by the sender, to decrypt it into the original format.

Features of Encryption System :
1. GUI based file selection facility, to select the original file and the cipher text file.
2. Facility to save the converted Cipher Text into your PC and then send that file to the receiver.
3. Use any combination of password for encryption, but the same password has to be used while decrypting otherwise the decrypted contain will get altered by a huge margin, so any gaussing of the password will not do the trick.
4. Secure while transmitting over unsecure network like public network.
5. 100 % accuracy, as the original file and the final decrypted file are same.
6. Well tested.
